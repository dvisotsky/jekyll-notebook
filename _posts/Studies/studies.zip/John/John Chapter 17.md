[Back](./index.md)
# Recap
We are at the end of Jesus' time with his disciples.
He has spent time encouraging them and preparing them for the journey ahead.

# The Prayer
Let's be judgmental for a second.
What can you tell about someone from how they pray?

**Why are we shy to pray out loud in groups?**
- It's difficult to be sincere in large groups of people who you're not close with
- Prayer is supposed to be a conversation between you and God
- It reveals - to an extent - how well you know God
- Is your relationship with Him stronger than your fear of those around you?
	- Can you bock out the pressure and be sincere anyway?

**Does Jesus’ prayer match the template of the Lord’s Prayer?**
Can you line up the sections of His prayer to sections of the Lord's Prayer?
Is anything missing?

[Matthew 6:9-13](https://www.esv.org/Matthew+6/)
> Pray then like this: 
	Our Father in heaven, hallowed be your name.  
	Your kingdom come, your will be done,  
	on earth as it is in heaven.  
	Give us this day our daily bread, and forgive us our debts,  
	 as we also have forgiven our debtors.  
	And lead us not into temptation, but deliver us from evil.

**Does Jesus’ prayer match the template of the Lord’s Prayer?**


We are also to call God our Father - Galatians 4:6

