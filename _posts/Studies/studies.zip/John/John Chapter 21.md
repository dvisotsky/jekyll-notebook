# Recap
Jesus is alive!
His mission is complete, but there are a few things to tidy up.

# Context

# Breakfast by the Sea
_verses 1 - 14_
> Simon Peter, Thomas (called the Twin), Nathanael of Cana in Galilee, the sons of Zebedee, and two others of his disciples were together. Simon Peter said to them, “I am going fishing.” They said to him, “We will go with you.”

_Q: Why do you think Peter decided to go fishing?_
Don't they know that Jesus is back?

After a long night, their work is fruitless - or rather fishless.

_Q: Why did casting the net on the right side of the boat work?_
Jesus said so. In this case it is that simple.
Working under the direct guidance of God typically has this kind of effect.

**Quick maths:**
153 fish. How heavy do you think that one fish is? 
What about a wet net big enough to hold 153 fish? Peter seems to be pretty jacked.
 - One scholar (Tenney) puts the total weight at around 300 pounds.
 - ChatGPT estimates between 325 and 510 pounds

>When they got out on land, they saw a charcoal fire in place, with fish laid out on it, and bread. _- John 21:9_

_Who prepared the fire, fish, and bread?_
"Come and have breakfast"

Jesus is always inviting. These disciples fled and scattered not long ago, yet here Jesus again shows his strength in humility.

# Do you love me?
_verses 15-19_

*Q: What do you think Jesus is feeling here? Is there and hint of malice or vengeance?*
No, only a desire for Peter to actually think about his answer and be truthful with himself.

*Q: What does Jesus mean by "more than these?" Who is Jesus referring to?*
(Check out Matthew 26:33)

*Q: Why did Jesus ask 3 times?*
Just like when he denied Jesus, Peter did not think clearly, at least not at first, when he answered.

*Q: Who else betrayed Jesus but did not receive restoration like Peter did?*
Why didn't Judas become a missionary like the other disciples?

*Q: What did Jesus mean "feed my sheep?"*
Peter's a fisherman, what does he know about sheep?

What does it mean for you to "Feed the sheep?"
These are Sheep, not chickens. It is not enough to throw them feed. They need guidance and care.

