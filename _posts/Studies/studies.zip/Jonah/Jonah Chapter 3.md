[Back](./index.md)

#lesson #bible_study #Jonah 

## Quick Recap
Jonah was a prophet.
Assigned by God to preach to Nineveh and encourage it to repent.
- Nineveh was not just Las Vegas or LA. It was a nation that was against Israel and would later conquer part of it.
- At that time the Assyrian empire was one of the cruelest and most aggressive in Mesopotamia. The Assyrians had destroyed scores of cities and villages and forcibly relocated or enslaved other groups of people, cutting a large swath along the Fertile Crescent. In the 720s BCE, they attacked and conquered Israel, the prosperous northernmost Jewish kingdom, and the southern kingdom, Judah, was reduced to paying heavy tribute. Assyria was thus one of the Jews’ most feared and hated enemies. - [Encyclopedia Britannica](https://www.britannica.com/biography/Jonah-biblical-figure)

Intro Questions:
* What new things have you learned about Jonah so far?
* Who are the Assyrians in our day and age? Who are they for you?

Jonah was loyal to his nation and people.
He did not want to serve Nineveh because they were evil and against Israel.

## Jonah 3:1-5
Jonah finally agreed to go to Nineveh, he's been convinced.

Q: Why didn't God just find someone else for the job?
	God wanted to show Jonah something

Q: Who else needed a second chance to follow God's will?
	- Peter denied Jesus 3 times
	- Israel in the desert
	- Elijah ran away from Jezebel and asked for God to take his life.
	- Nineveh

[map to Nineveh](https://images.squarespace-cdn.com/content/v1/54111b43e4b04f85eb6b8afe/1610059125417-3S08TFVDBZY8ZWNI4CFP/6f3d9-jonahrunswithdistances.jpg?format=2500w)


**Jonah Preaches**
"Yet forty days, and Nineveh will be overthrown!"


