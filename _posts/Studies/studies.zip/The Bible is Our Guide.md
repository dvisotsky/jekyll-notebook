[Back](./index.md)

Awana TnT 2 Lesson - 2.7
April 12, 2024

Memory Verse:
> Your word is a lamp unto my feet and a light to my path - Psalm 119:105

Start with the object lesson, don't share the key verse from the beginning.
## Object Lesson: Scavenger Hunt
Find the following and bring it back to your seat to win.
The list must stay put, pictures and taking notes is prohibited.

- 2 Pine cones
- 1 pencil
- 1 Wood chip
- 1 shoe 
- 1 clover
- 2 leaves, must be from different types of trees
- If you bring 3 leaves, you don't need to bring a shoe
- 1 wet rock
- 1 high five from each TnT 2 leader (except for the ones that are absent)
- 1 four leaf clover to automatically win

## Discussion
- Did you instantly know all the things on the list?
- Did you memorize one or two and come back for the next one or two?
- Did you read the entire thing first or just a couple?
- Would it have helped to have a copy of the list with you while you were out looking?

- How does any of this connect to the Bible?
Now we bring out the bible verse (Psalm 119:105)

The Bible is our guide to what we need to collect to have a blessed life.
But we don't collect physical things, *because what is essential is invisible to the eye*.

- What are some examples of things that the Bible tells us to collect?
	- obedience
	- patience
	- kindness

The better you know the Bible, the better you'll know what you need to succeed in life.
